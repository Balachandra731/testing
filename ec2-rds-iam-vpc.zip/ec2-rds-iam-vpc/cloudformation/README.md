# CloudFormation project
Placeholder files. Replace with full template or ask me to regenerate full CloudFormation template.
